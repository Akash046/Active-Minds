import React, { useEffect } from "react";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";
import badWords from "bad-words";
import toast from "react-hot-toast";
const Dictaphone = ({ isMuted, setIsMuted }) => {
  const {
    transcript,
    listening,
    resetTranscript,
    browserSupportsSpeechRecognition,
  } = useSpeechRecognition();

  SpeechRecognition.startListening({ continuous: true });

  useEffect(() => {
    const filter = new badWords();
    if (transcript) {
      filter.addWords("dog", "motherboard", "cat");
      if (filter.isProfane(transcript)) {
        setIsMuted(true);
        resetTranscript();
        toast.error("Profanity detected, you are muted for 5s");
        setTimeout(() => {
          setIsMuted(false);
        }, 5000);
      }
    }
  }, [transcript]);
  if (!browserSupportsSpeechRecognition) {
    return <span>Browser doesn't support speech recognition.</span>;
  }
  return <div></div>;
};
export default Dictaphone;
