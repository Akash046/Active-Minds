import * as React from 'react';
import { ZegoUIKitPrebuilt } from '@zegocloud/zego-uikit-prebuilt';
import { useParams } from 'react-router-dom';
import { useSelector } from 'react-redux';

import { useNavigate } from 'react-router-dom';
import Dictaphone from "./Filtering";
import toast from "react-hot-toast";

const VedioCall = () => {
  const navigate = useNavigate();
  const user = useSelector((state) => state.user);
  const { roomID } = useParams();
  const [isMuted, setIsMuted] = React.useState(false);
  const appID = 1247083599;
  const serverSecret = "ee0fb1945ec127f5d07cb1be0057fae4";
  const muteButtonRef = React.useRef(null);
  const kitToken = ZegoUIKitPrebuilt.generateKitTokenForTest(
    appID,
    serverSecret,
    roomID,
    user._id,
    user.name
  );

  const zp = ZegoUIKitPrebuilt.create(kitToken);

  const myMeeting = async (element) => {
    zp.joinRoom({
      container: element,
      showMyMicrophoneToggleButton: true,
      showUserList: true,

      scenario: {
        mode: ZegoUIKitPrebuilt.GroupCall,
        showLayoutButton: false,

        showScreenSharingButton: false,

        // To implement 1-on-1 calls, modify the parameter here to [ZegoUIKitPrebuilt.OneONoneCall].
      },
    });
  };
  React.useEffect(() => {
    let interval;

    interval = setInterval(() => {
      let elements = document.getElementsByClassName(
        "QYvze2FiFrLlotTk5Iz7 false"
      );
      if (elements.length > 0) {
        let mutebutton = elements[0];
        if (isMuted) {
          mutebutton.click();
        }
      }
    }, 800);
    return () => {
      clearInterval(interval);
    };
  }, [isMuted]);

  return (
    <div>
      <div>
        <div ref={myMeeting} />
      </div>
      <Dictaphone isMuted={isMuted} setIsMuted={setIsMuted} />
    </div>
  );
};

export default VedioCall;