const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(`mongodb+srv://garbage:q48gzXBEq0vlijg6@cluster0.hxyrlvf.mongodb.net/raj?retryWrites=true&w=majority&appName=Cluster0`, ()=> {
  console.log('connected to mongodb')
})
